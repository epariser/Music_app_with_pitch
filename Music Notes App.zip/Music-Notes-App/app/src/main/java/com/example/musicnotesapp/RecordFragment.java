package com.example.musicnotesapp;


import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.example.musicnotesapp.music.NotePitchMap;
import com.example.musicnotesapp.uihelper.UIHelper;
import com.example.musicnotesapp.dsp.MPM;


/**
 * A simple {@link Fragment} subclass.
 */
public class RecordFragment extends Fragment implements View.OnClickListener {

    private static AudioRecord recorder;
    private static short[] data;
    private static final int SAMPLE_RATE = 48000;
    private static final int SAMPLES = 1024;
    private static final MPM mpm = new MPM(SAMPLE_RATE, SAMPLES, 0.93);
    private static int N;
    //private static UIHelper uiHelper;


    private NavController navController; // have nav controller so we navigate through fragments
    private ImageButton recordBtn; // recording button
    private Button backBtn; // back button to return to previous menu
    private TextView filenameText; // get the text box to display filename
    private TextView noteOutputTextView; // get text box to display pitch

    private String recordPermission = Manifest.permission.RECORD_AUDIO; // permission string
    private int PERMISSION_CODE = 5; // permission code var

    private static boolean isRecording = false; // boolean to check if recording
    //private MediaRecorder recorder; // create the object that records
    private String recordFile; // output file of recording

    private Chronometer timer; // to create timer of how long recording has gone on for

    public RecordFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_record, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState); // call parent class

        navController = Navigation.findNavController(view); // set navController
        recordBtn = view.findViewById(R.id.record_btn); // find recording button
        backBtn = view.findViewById(R.id.go_back); // find back button
        timer = view.findViewById(R.id.record_timer); // find the timer on the xml
        filenameText = view.findViewById(R.id.record_filename); // find text box
        noteOutputTextView = view.findViewById(R.id.noteOutputTextView); // find pitch text box

        backBtn.setOnClickListener(this); // call OnClick if button is pressed
        recordBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.record_btn:
                if(isRecording) { // stop recording
                    // Stop Recording
                    stopRecording();

                    // put in the is not recording button
                    recordBtn.setImageDrawable(getResources().getDrawable(R.drawable.record_btn_stopped, null));
                    isRecording = false; // set recording to false
                } else {
                    // Start Recording
                    if(checkPermissions()){ // check permission to record audio
                        startRecording();
                        // put in the is recording button
                        recordBtn.setImageDrawable(getResources().getDrawable(R.drawable.record_btn_recording, null));
                        isRecording = true; // set recording to true
                    }
                }
                break;

            case R.id.go_back: // if pressed back button
                if(isRecording){ // if is recording
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext()); //make alert box
                    alertDialog.setPositiveButton("OKAY", new DialogInterface.OnClickListener() { // make OKAY button
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) { // if clicked ok
                            // goto file view fragment
                            navController.navigate(R.id.action_recordFragment_to_fileListFragment);
                        }
                    });
                    alertDialog.setNegativeButton("CANCEL", null); // make cancel button
                    alertDialog.setTitle("Audio Still Recording"); // title of alert box
                    alertDialog.setMessage("Are you sure, you want to stop the recording?"); // if pressed okay
                    alertDialog.create().show(); // create and show the alert box
                } else { // if not recording
                    navController.navigate(R.id.action_recordFragment_to_fileListFragment); // go to file fragment
                }
                break;
        }
    }
    private void stopRecording() {
        timer.stop(); // stop the timer

        filenameText.setText("Recording Stopped, File Saved : " + recordFile);

        recorder.stop(); // stop recording
        recorder.release(); // release the recorder
        recorder = null; // set recorder to null so can use again
        //isRecording = false; // needed to end pitch detection loop.
    }

    private void startRecording() {
        timer.setBase(SystemClock.elapsedRealtime()); // set the initial time of clock
        timer.start(); // start the timer
        // get file path
        String recordPath = getActivity().getExternalFilesDir("/").getAbsolutePath();
        // get the date
        SimpleDateFormat formatter = new SimpleDateFormat("yyy_MM_dd_hh_mm_ss", Locale.US);
        // create date object
        Date now = new Date();

        // format file string
        recordFile = "Recording_" + formatter.format(now) + ".3gp"; // filename

        // fill text box with what file is recording
        filenameText.setText("Recording, File Name : " + recordFile);
        N = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        data = new short[SAMPLES];
        recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, N * 10);
        //recorder.setAudioSource(MediaRecorder.AudioSource.MIC); // get microphone
        //recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP); // record in THREE_GPP
        //recorder.setOutputFile(recordPath + "/" + recordFile); // set the output file of recording
        //recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB); // set the audio encoder

        // prepare the recorder it requires it be wrapped around try and catch


        recorder.startRecording(); // start the recording
        //isRecording = true; // to activate loop in run()
        run();
    }

    public void run() {
        while ((isRecording == true)) {
            try {
                recorder.read(data, 0, data.length);
                double pitch = mpm.getPitchFromShort(data);
                String note = NotePitchMap.displayNoteOf(pitch);
                noteOutputTextView.setText("" + note); //print note
            } catch (Throwable x) {
                x.printStackTrace();
                System.exit(-1);
            }
        }
        return;
    }

    private boolean checkPermissions() {
        // if have permission return true
        if(ActivityCompat.checkSelfPermission(getContext(), recordPermission) == PackageManager.PERMISSION_GRANTED){
            return true;
        }
        else{ // if dont have permission request
            ActivityCompat.requestPermissions(getActivity(), new String[]{recordPermission}, PERMISSION_CODE);
            return false;
        }
    }

    @Override
    public void onStop(){ // on leaving current fragment
        super.onStop(); // if navigate to diff fragment
        if(isRecording) { // if recording
            stopRecording(); //stop recording audio
        }
    }
}
