# Music Notes App
 Android application for music composers and songwriters to make notes and voice recordings
